from django.apps import AppConfig


class MyResumeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'my_resume'
